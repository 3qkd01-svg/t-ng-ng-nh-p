import { chromium } from 'playwright-core';
import { createInterface } from 'node:readline/promises';
import { mkdir, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';
import { setTimeout as delay } from 'node:timers/promises';
import { installFastClick, nextWindow } from './fast-click.mjs';
import { createChatRecovery } from './chat-recovery.mjs';
import { attachLatencyDiagnostics } from './opt-diagnostics.mjs';
import { installOpenDiagnostics } from './plan1-common.mjs';
import { LOGIN_TIMEOUT_MS, normalizeTargetUrl, waitForLogin, within } from './startup-link120.mjs';
import { installRequestHealth, OPEN_TIMEOUT_MS, readBusinessResult, parseRetryAfter } from './request-health.mjs';
import { createCpuBoost } from './cpu-boost.mjs';
import { installBrowserPolicy, createPeakWindow } from './browser-peak.mjs';
import { createScheduledReload, RELOAD_LEAD_MS } from './scheduled-reload.mjs';
import { loadSavedLogin, savedStateFor, createLoginPersistence } from './session-store.mjs';
export { LOGIN_TIMEOUT_MS, normalizeTargetUrl, waitForLogin } from './startup-link120.mjs';

const unique = () => '__retry500_' + randomUUID().replaceAll('-', '');
const isClaim = request => /\/chat\/grabred\/?$/i.test(new URL(request.url()).pathname);
export function formatHanoiClock(at) {
  const date = new Date(at + 7 * 3600000), pad = value => String(value).padStart(2, '0');
  return `${pad(date.getUTCHours())}:${pad(date.getUTCMinutes())}:${pad(date.getUTCSeconds())} ${pad(date.getUTCDate())}/${pad(date.getUTCMonth()+1)}/${date.getUTCFullYear()}`;
}
export function determineRunTime(answer = '', now = Date.now()) {
  const input = answer.trim(), window = nextWindow(input ? Number(input) : undefined, now);
  return { currentAt: now, automatic: !input, ...window, reloadAt: window.startAt - RELOAD_LEAD_MS, enterChatAt: window.startAt - 3000 };
}
export function formatRemaining(ms) {
  const seconds = Math.max(0, Math.ceil(ms / 1000));
  return `${Math.floor(seconds/3600)} gio ${Math.floor(seconds/60)%60} phut ${seconds%60} giay`;
}
export function nextContinuousWindow(lastStart, now = Date.now()) {
  return nextWindow(undefined, Math.max(lastStart, now));
}
async function waitUntil(at, stopped, pollMs = 250) {
  while (Date.now() < at) {
    if (stopped()) throw Error('STOPPED');
    await delay(Math.min(pollMs, at-Date.now()));
  }
  if (stopped()) throw Error('STOPPED');
}

// One persistent browser session. Socket listeners belong to the session;
// request budgets, first-envelope selection and recovery belong to each round.
export async function createRetrySession(context, page, origin) {
  const session = { context, page, origin, liveSockets: new Set(), lastFrame: 0, skippedMedia: 0, active: null };
  session.healthEvents=[];session.claimBackoffUntil=0;
  await context.exposeBinding('__pa1HealthNotify',(_source,event)=>{
    if(!event||!['notice','xhr-terminal'].includes(event.kind))return;
    const timestamp=value=>typeof value==='string'&&value.length<=40&&Number.isFinite(Date.parse(value))?new Date(value).toISOString():null;
    const integer=value=>Number.isSafeInteger(value)&&value>=0?value:null;
    const safe={kind:event.kind,at:timestamp(event.at),category:['rate-limit','network-no-response','claim-failed'].includes(event.category)?event.category:null};
    if(event.kind==='xhr-terminal'&&event.terminal&&['load','error','timeout','abort'].includes(event.terminal.type)){
      safe.sentAt=timestamp(event.sentAt);safe.timeoutMs=integer(event.timeoutMs);safe.originalTimeoutMs=integer(event.originalTimeoutMs);
      safe.terminal={type:event.terminal.type,at:timestamp(event.terminal.at),elapsedMs:integer(event.terminal.elapsedMs),httpStatus:integer(event.terminal.httpStatus),actualTimeoutMs:integer(event.terminal.actualTimeoutMs)};
    }
    session.healthEvents.push(safe);if(session.healthEvents.length>128)session.healthEvents.shift();
    if(safe.category==='rate-limit')session.claimBackoffUntil=Math.max(session.claimBackoffUntil,Date.now()+60000);
    session.active?.health?.(safe);
  });
  await page.addInitScript(installRequestHealth);
  page.on('websocket', socket => {
    session.active?.connection();
    socket.on('close', () => session.liveSockets.delete(socket));
    socket.on('socketerror', () => session.active?.socketError());
    socket.on('framereceived', ({ payload }) => {
      session.liveSockets.add(socket); session.lastFrame = Date.now(); session.active?.frame();
      if (payload.length > 524288) return;
      try {
        const event = JSON.parse(typeof payload === 'string' ? payload : payload.toString('utf8'));
        if (event?.type === 'chat_red') session.active?.event(event.data);
      } catch {}
    });
  });
  session.healthy = () => session.liveSockets.size > 0 && Date.now()-session.lastFrame < 60000;
  // Let the site's current bootstrap request finish before recovery navigates
  // away. Track only bounded in-memory request references, never credentials.
  const bootstrap = new Map(); let settledAt = -Infinity;
  page.on('request',request=>{
    if(bootstrap.size>=100)return;
    try{
      const url=new URL(request.url()),document=request.resourceType()==='document'&&request.frame()===page.mainFrame();
      if(url.origin===origin&&(document||/\/chat\/(getToken|getChatLog)\/?$/i.test(url.pathname)))
        bootstrap.set(request,{at:Date.now(),timeoutMs:document?30000:20000});
    }catch{}
  });
  const settled=request=>{if(bootstrap.delete(request))settledAt=Date.now();};
  page.on('requestfinished',settled);page.on('requestfailed',settled);
  session.bootstrapBusy=()=>{
    const now=Date.now();for(const [request,state]of bootstrap)if(now-state.at>=state.timeoutMs)bootstrap.delete(request);
    return bootstrap.size>0||now-settledAt<750;
  };
  session.browserPolicy=await installBrowserPolicy(context,page,session);
  return session;
}

export async function prepareRetryUI(session, { startAt, endAt, key, mark, cancelled, initialWarmup = true,
  leadMs = 3000, pollMs = 500, loginTimeoutMs = LOGIN_TIMEOUT_MS, warmupTimeoutMs = 20000, reloadBeforeEntry=async()=>{} }) {
  const { page } = session, enterAt = startAt-leadMs;
  function check() {
    if (cancelled()) throw Error('STOPPED');
    if (page.isClosed()) throw Error('PAGE_CLOSED');
    if (Date.now() >= endAt) throw Error('WINDOW_ENDED');
  }
  async function until(test, timeoutAt = endAt) {
    while (true) {
      check(); if (await test()) return;
      if (Date.now() >= timeoutAt) throw Error('CHAT_NOT_READY');
      await delay(pollMs);
    }
  }
  async function route(hash, label) {
    check(); mark(label+'-requested');
    await page.evaluate(({hash,endAt}) => { if(Date.now()<endAt)location.hash=hash; }, {hash,endAt});
    await until(() => page.evaluate(hash => location.hash===hash, hash), Math.min(endAt,Date.now()+20000));
    mark(label+'-entered');
  }
  async function ready() {
    await page.evaluate(k => window[k]?.stop(), key);
    const status = await page.evaluate(installFastClick,{key,startAt,endAt});
    await page.evaluate(k => window[k]?.stop(), key);
    return status.inChat && status.supported && status.loggedIn;
  }
  mark('waiting-login');
  await waitForLogin(page,{timeoutMs:loginTimeoutMs,cancelled,pollMs:Math.min(pollMs,250)});
  mark('login-detected');
  if (initialWarmup) {
    await route('#/chatRoom','warm-chat');
    try { await until(ready,Math.min(endAt,Date.now()+warmupTimeoutMs)); }
    catch(error) { check(); if(error.message!=='CHAT_NOT_READY')throw error; mark('warm-chat-not-ready'); }
    if (Date.now()<enterAt) await route('#/','home');
  }
  await reloadBeforeEntry();check();
  if (Date.now()<enterAt) await waitUntil(enterAt,cancelled,pollMs);
  await route('#/chatRoom','return-chat');
  await until(ready,Math.min(endAt,Date.now()+20000));
  await until(async()=>session.healthy(),Math.min(endAt,Date.now()+15000));
  check();
  const result=await page.evaluate(installFastClick,{key,startAt,endAt});
  if (!result.loggedIn || !result.supported || !result.inChat) throw Error('CHAT_NOT_READY');
  await page.evaluate(installOpenDiagnostics,key);
  mark('armed');
}

export async function runRetryRound(session, options) {
  const {context,page,origin}=session;
  const {startAt,endAt=startAt+60000,leadMs=3000,initialWarmup=true,observeOnly=false,
    cancelled=()=>false,pollMs=250,loginTimeoutMs=LOGIN_TIMEOUT_MS,warmupTimeoutMs=20000,
    reloadLeadMs=RELOAD_LEAD_MS,reloadTimeoutMs=30000,bodyReadTimeoutMs=10000}=options;
  let stopped=false,armed=false,chosen=false,offered=false,chosenId=null,first=null,allowedClaims=0;
  let recovery,recoveryTimer,diagnostics,setup,peak;
  const key=unique(),seen=new Set(),records=new Map(),mediaBefore=session.skippedMedia;
  const report={version:9,plan:'plan1',build:'pa1netfix',release:'0.10.0-netfix',startedAt:new Date().toISOString(),
    navigation:[],ws:{connections:0,frames:0,errors:0,events:0},request:null,requests:[],clicks:null,endReason:null,
    mode:observeOnly?'observe-only':'native-single-open-when-ready',blockedClaimRequests:0,
    delivery:{state:'waiting-event',queuedForReadiness:false,offeredAt:null,readinessWaitMs:null},
    clickPolicy:{firstOpenDelayMs:0,secondAfterFirstOpenMs:null,maxNativeRequests:1,releaseOpeningFlagForSecond:false},
    window:{startAt,endAt,enterChatAt:startAt-leadMs},transport:{nativeOpenXhrMinimumMs:OPEN_TIMEOUT_MS,unlimitedTimeoutPreserved:true},
    rateLimit:{detected:false,until:null,source:null},nativeHealth:[],cpuBoost:session.cpuBoost?.reportFor(startAt)??{enabled:false,state:'not-configured'},
    clock:{timezone:'Asia/Ho_Chi_Minh',currentAt:Date.now(),nextStartAt:startAt,followingStartAt:nextContinuousWindow(startAt,startAt).startAt}};
  const mark=step=>{report.navigation.push({step,at:new Date().toISOString()});console.log(step);};
  let resolveFinished;const finished=new Promise(r=>{resolveFinished=r;});
  const stop=reason=>{if(!stopped){stopped=true;armed=false;report.endReason=reason;resolveFinished();}};
  const shouldStop=()=>stopped||cancelled()||page.isClosed();
  const recordLimit=(source,until=Date.now()+60000)=>{
    session.claimBackoffUntil=Math.max(session.claimBackoffUntil??0,until);
    report.rateLimit={detected:true,until:new Date(session.claimBackoffUntil).toISOString(),source};
  };
  const scheduledReload=createScheduledReload(session,{startAt,enterAt:startAt-leadMs,mark,cancelled:shouldStop,
    pollMs,reloadLeadMs,reloadTimeoutMs,loginTimeoutMs});
  report.preRunReload=scheduledReload.report;
  function offerChosen(){
    if(!armed||!chosen||offered||shouldStop()||Date.now()>=endAt)return;
    if(Date.now()<(session.claimBackoffUntil??0)){recordLimit('cooldown',session.claimBackoffUntil);stop('rate-limit-cooldown');return;}
    offered=true;report.delivery.state='offered';report.delivery.offeredAt=new Date().toISOString();
    report.delivery.readinessWaitMs=Math.round(performance.now()-first.mono);
    void page.evaluate(({key,id,at,endAt})=>Date.now()<endAt&&(window[key]?.offer(id,at)??false),{key,id:chosenId,at:report.eventAt,endAt})
      .then(ok=>{if(!ok&&!stopped)stop('click-adapter-unavailable');}).catch(()=>stop('page-unavailable'));
  }
  const active={
    health(event){if(event.category==='rate-limit'){recordLimit('ui-notice');if(!records.size)stop('rate-limited-before-open');}},
    connection(){report.ws.connections++;},frame(){report.ws.frames++;},socketError(){report.ws.errors++;},
    allow(request){
      let id;
      try {id=String(JSON.parse(request.postData()||'{}').red_id);}catch{}
      let main=false;
      try {main=request.frame()===page.mainFrame();}catch{}
      if(observeOnly||shouldStop()||!armed||allowedClaims>=1||Date.now()<(session.claimBackoffUntil??0)||!chosenId||id!==chosenId||
        request.method()!=='POST'||new URL(request.url()).origin!==origin||!main){report.blockedClaimRequests++;return false;}
      allowedClaims++;return true;
    },
    event(data){
      report.ws.events++;
      if(!data||!['string','number'].includes(typeof data.red_id))return;
      const id=String(data.red_id);
      if(!id||id.length>256||seen.has(id)||seen.size>=2000)return;
      seen.add(id);
      if(shouldStop()||chosen||Date.now()<startAt||Date.now()>=endAt)return;
      if(['limit_turnover','limit_deposit'].some(k=>data[k]!=null&&Number(data[k])!==0))return;
      chosen=true;chosenId=id;first={id,mono:performance.now()};report.eventAt=new Date().toISOString();
      report.delivery.queuedForReadiness=!armed;
      report.delivery.state=armed?'ready-to-offer':'queued-for-readiness';
      diagnostics?.noteEvent(data,report.eventAt);
      if(observeOnly){report.delivery.state='observed-only';stop('event-observed');return;}
      if(!armed)mark('event-waiting-readiness');
      offerChosen();
    }
  };
  function onRequest(request){
    if(observeOnly||!armed||shouldStop()||records.size>=1||request.method()!=='POST'||!isClaim(request))return;
    let id;try{id=String(JSON.parse(request.postData()||'{}').red_id);}catch{return;}
    if(id!==chosenId||new URL(request.url()).origin!==origin)return;
    const mono=performance.now(),item={number:records.size+1,sentAt:new Date().toISOString(),
      eventToRequestMs:first?Math.round(mono-first.mono):null,httpStatus:null,applicationCode:null,applicationMessage:null,bodyState:'pending',responseMs:null,finishedMs:null,failure:null,state:'pending'};
    let settle;const settled=new Promise(r=>{settle=r;});
    records.set(request,{item,mono,settle,settled});report.requests.push(item);report.request??=item;
    console.log('Yeu cau '+item.number+' bat dau.');
  }
  function onResponse(response){
    const rec=records.get(response.request());if(!rec)return;
    rec.item.httpStatus=response.status();rec.item.responseMs=Math.round(performance.now()-rec.mono);
    if(response.status()===429)recordLimit('http-429',parseRetryAfter(response.headers()['retry-after'])??Date.now()+60000);
    console.log('Yeu cau '+rec.item.number+': HTTP '+response.status());
  }
  function onFinished(request){const rec=records.get(request);if(!rec)return;
    rec.item.finishedMs=Math.round(performance.now()-rec.mono);rec.item.state='finished';
    rec.bodyTask=(async()=>{try{const response=await request.response();
      if(Number(response.headers()['content-length']||0)>524288)return {bodyState:'too-large'};
      return readBusinessResult(await response.body());}catch{return {bodyState:'unavailable'};}})();
    rec.settle();stop('response-finished');}
  function onFailed(request){const rec=records.get(request);if(!rec)return;
    rec.item.finishedMs=Math.round(performance.now()-rec.mono);
    rec.item.failure=request.failure()?.errorText?.match(/\bERR_[A-Z_]{1,60}\b/)?.[0]||'OTHER_NETWORK_ERROR';
    rec.item.state='failed';rec.settle();if([...records.values()].every(r=>r.item.state!=='pending'))stop('request-failed');}
  context.on('request',onRequest);context.on('response',onResponse);context.on('requestfinished',onFinished);context.on('requestfailed',onFailed);
  session.active=active;
  const monitor=setInterval(()=>{
    if(cancelled()||page.isClosed())return stop(cancelled()?'user-stopped':'page-closed');
    if(Date.now()>=endAt&&records.size===0)return stop('window-ended');
    if(Date.now()>=endAt+OPEN_TIMEOUT_MS+5000)stop('response-deadline');
  },Math.min(pollMs,100));
  try{
    peak=createPeakWindow(session,{key:key+'_peak',startAt,endAt,leadMs,cancelled:shouldStop});peak.start();
    diagnostics=await attachLatencyDiagnostics(context,page,{startAt,endAt,origin,key:key+'_latency'});
    setup=(async()=>{
      await prepareRetryUI(session,{startAt,endAt,leadMs,key,mark,cancelled:shouldStop,initialWarmup,pollMs,loginTimeoutMs,warmupTimeoutMs,
        reloadBeforeEntry:async()=>{await scheduledReload.run();await session.persistence?.checkpoint('before-chat');}});
      if(shouldStop())return;
      armed=true;console.log('DA SAN SANG: ket noi chat dang hoat dong.');offerChosen();
      recovery=createChatRecovery({healthy:session.healthy,
        canObserve:()=>!shouldStop()&&!offered&&Date.now()<endAt,
        canRecover:()=>!shouldStop()&&!chosen&&records.size===0&&Date.now()<endAt&&!peak.deferRecovery(),
        ready:async value=>{
          armed=false;
          if(value&&!shouldStop()&&!offered&&records.size===0){
            await page.evaluate(k=>window[k]?.stop(),key);
            const status=await page.evaluate(installFastClick,{key,startAt,endAt});
            await page.evaluate(installOpenDiagnostics,key);
            armed=!shouldStop()&&!offered&&status.inChat&&status.supported&&status.loggedIn;
            offerChosen();
          }return armed;
        },log:mark,recover:async()=>{
          if(shouldStop()||chosen||records.size)return;
          if(recovery.snapshot().attempts>1){session.liveSockets.clear();await page.reload({waitUntil:'domcontentloaded',timeout:15000});}
          else{await page.evaluate(()=>{location.hash='#/';});await delay(500);}
          if(!shouldStop()&&!chosen&&!records.size&&Date.now()<endAt)await page.evaluate(()=>{location.hash='#/chatRoom';});
        }});
      recoveryTimer=setInterval(()=>{void recovery.tick().catch(()=>{});},pollMs);
    })().catch(error=>{if(!stopped)stop(['LOGIN_TIMEOUT','CHAT_NOT_READY','WINDOW_ENDED','PAGE_CLOSED','STOPPED'].includes(error.message)?error.message:'setup-failed');});
    await finished;
    scheduledReload.stop();
    if(chosen&&!offered&&!observeOnly)report.delivery.state=Date.now()>=endAt?'window-ended-before-ready':'stopped-before-ready';
    for(const rec of records.values()){
      if(rec.item.state==='finished'){
        const result=await within(rec.bodyTask??Promise.resolve({bodyState:'unavailable'}),bodyReadTimeoutMs,{bodyState:'read-timeout'});
        // Commit once. A late body reader cannot mutate an already-finalized result.
        Object.assign(rec.item,result);
        if(result.noticeCategory==='rate-limit')recordLimit('server-message');
      }else rec.item.bodyState=rec.item.state==='failed'?'no-response':'pending';
    }
    report.clicks=await within(page.evaluate(k=>{const v=window[k]?.snapshot()??null;window[k]?.stop();return v;},key).catch(()=>null));
    report.diagnostics=await diagnostics.finish();diagnostics=null;
    report.browserPeak=await peak.finish();peak=null;
    report.nativeHealth=session.healthEvents.filter(e=>Date.parse(e.at??e.terminal?.at)>=Date.parse(report.startedAt));
    for(const rec of records.values()){
      const match=report.nativeHealth.find(e=>e.kind==='xhr-terminal'&&e.sentAt&&Math.abs(Date.parse(e.sentAt)-Date.parse(rec.item.sentAt))<1500);
      if(match)rec.item.nativeTerminal=match.terminal;
    }
    const successes=report.requests.filter(r=>r.applicationCode===1).map(r=>r.number);
    report.outcome={state:observeOnly?'observe-only':successes.length?'confirmed-success':report.rateLimit.detected?'rate-limited':!report.requests.length?'not-attempted':report.requests.some(r=>r.applicationCode===null)?'unknown-no-response':'not-confirmed',successfulRequestNumbers:successes,
      nativeRequests:report.requests.length,httpResponses:report.requests.filter(r=>r.httpStatus!==null).length};
    report.recovery=recovery?.snapshot()??null;report.media={skipped:session.skippedMedia-mediaBefore};
    report.finishedAt=new Date().toISOString();report.clock.nextAfterFinishAt=nextContinuousWindow(startAt,Date.parse(report.finishedAt)).startAt;
    return report;
  }finally{
    stopped=true;armed=false;clearInterval(monitor);clearInterval(recoveryTimer);
    scheduledReload.stop();
    if(session.active===active)session.active=null;
    context.off('request',onRequest);context.off('response',onResponse);context.off('requestfinished',onFinished);context.off('requestfailed',onFailed);
    if(diagnostics)await diagnostics.finish().catch(()=>{});
    if(peak)await peak.finish().catch(()=>{});
    await within(page.evaluate(k=>{window[k]?.stop();delete window[k];delete window[k+'_latency'];},key).catch(()=>{}));
    void setup;
  }
}

export async function holdThenHome(session,report,{cancelled=()=>false,holdMs=300000,pollMs=250}={}){
  const at=Date.parse(report.finishedAt)+holdMs;
  report.postRun={homeAfterMs:holdMs,holdUntil:new Date(at).toISOString(),homeAt:null,state:'holding-chat'};
  try{
    await waitUntil(at,()=>cancelled()||session.page.isClosed(),pollMs);
    const changed=await within(session.page.evaluate(origin=>{
      if(location.origin!==origin)return false;location.hash='#/';return true;
    },session.origin),2000,false);
    report.postRun.state=changed?'home':'home-unavailable';
    if(changed)report.postRun.homeAt=new Date().toISOString();
  }catch{report.postRun.state='interrupted';}
}

export async function runRetrySchedule(session,{firstWindow,cancelled=()=>false,outputDir,observeOnly=false,
  onReport=()=>{},next=nextContinuousWindow,round=runRetryRound,holdMs=300000,pollMs=250,...roundOptions}={}){
  let window=firstWindow,initialWarmup=true,completed=0,lastReport=null,lastReportFile=null;
  while(!cancelled()&&!session.page.isClosed()){
    session.persistence?.setWindow(window);
    await session.cpuBoost?.schedule(window.startAt);
    console.log('Gio hien tai (Ha Noi): '+formatHanoiClock(Date.now()));
    console.log('Phien se chay: '+formatHanoiClock(window.startAt)+'; vao Chat: '+formatHanoiClock(window.startAt-(roundOptions.leadMs??3000)));
    console.log('Tai lai trang: '+formatHanoiClock(window.startAt-(roundOptions.reloadLeadMs??RELOAD_LEAD_MS))+' (bo qua neu da lo moc).');
    const report=await round(session,{...roundOptions,...window,initialWarmup,observeOnly,cancelled,pollMs});
    session.persistence?.endWindow();
    if(session.persistence){const savedRound=await session.persistence.checkpoint('after-round',{force:true});report.savedLogin=session.persistence.info();
      if(savedRound.state!=='saved')console.log('Chua cap nhat duoc phien; ban luu gan nhat van duoc giu.');}
    initialWarmup=false;completed++;
    report.startup={targetOrigin:session.origin,loginTimeoutMs:LOGIN_TIMEOUT_MS};
    report.continuous={enabled:true,state:'holding-chat',round:completed,nextStartAt:next(window.startAt,Date.now()).startAt};
    let path;
    if(outputDir){
      await mkdir(outputDir,{recursive:true});path=new URL('pa1retry500-'+window.startAt+'-'+Date.now()+'.json',outputDir);
      await writeFile(path,JSON.stringify(report,null,2));console.log('Bao cao: '+path.pathname.split('/').at(-1));
    }
    lastReport=report;lastReportFile=path;
    await onReport(report);
    if(cancelled()||session.page.isClosed()||['LOGIN_TIMEOUT','PAGE_CLOSED','page-closed','user-stopped','STOPPED'].includes(report.endReason)){
      report.continuous.state='stopped';if(path)await writeFile(path,JSON.stringify(report,null,2));return {completed,lastReport:report,lastReportFile:path};
    }
    console.log('Giu chat 5 phut, ve trang chu, TU CHAY dot tiep theo.');
    await holdThenHome(session,report,{cancelled,holdMs,pollMs});
    report.continuous.state=cancelled()||session.page.isClosed()?'stopped':'waiting-next-slot';
    if(path)await writeFile(path,JSON.stringify(report,null,2));
    if(cancelled()||session.page.isClosed())return {completed,lastReport:report,lastReportFile:path};
    window=next(window.startAt,Date.now());
  }
  return {completed,lastReport,lastReportFile};
}

export async function runPlan1(testOptions={}){
  const rl=testOptions.readline??createInterface({input:process.stdin,output:process.stdout});
  let browser,stopped=false,persistence,saveTimer,cpuBoost,scheduleResult;
  try{
    console.log('PA1NETFIX 0.10.0 (goc SAVELOGIN): Mo ngay khi san sang, DUY NHAT 1 LAN; vao chat truoc 3 giay; tai lai phut 57.');
    console.log('AboveNormal: tu T-30s den T+60s moi phien. Luu link/phien; dang nhap 120 giay.');
    const root=testOptions.dataDir??new URL('./',import.meta.url),saved=await loadSavedLogin(root);
    if(saved.url)console.log('Da co link luu. Enter de giu link; nhap link moi de doi.');
    else console.log('Lan dang nhap dau: nhap link va tu dang nhap trong 120 giay.');
    const link=await rl.question(saved.url?'Link HTTPS (Enter='+saved.url+'): ':'Link HTTPS (Enter de dung link hien tai): ');
    const target=testOptions.target??normalizeTargetUrl(link,saved.url??undefined);
    const stored=savedStateFor(saved,target);
    let restoreStatus=stored?'loaded':saved.url&&new URL(saved.url).origin!==new URL(target).origin?'different-origin':saved.status;
    const selected=(await rl.question('Trinh duyet 1=Edge, 2=Chrome [1]: ')).trim();
    const suggested=determineRunTime();console.log('Gio hien tai (Ha Noi): '+formatHanoiClock(suggested.currentAt));
    console.log('Khung ke tiep: '+formatHanoiClock(suggested.startAt));
    const answer=(await rl.question('Gio bat dau 11/13/15/17/19/21; Enter=dot ke tiep: ')).trim();determineRunTime(answer);
    const observeOnly=testOptions.observeOnly??((await rl.question('Che do 1=Mo mot lan ngay khi san sang, 2=Chi quan sat [1]: ')).trim()==='2');
    browser=await(testOptions.launch??(options=>chromium.launch(options)))({channel:selected==='2'?'chrome':'msedge',headless:false,
      args:['--disable-background-timer-throttling','--disable-renderer-backgrounding','--disable-backgrounding-occluded-windows']});
    const settings={viewport:null,acceptDownloads:false,serviceWorkers:'block'};
    let context;
    try{context=await browser.newContext({...settings,...(stored?{storageState:stored}:{})});}
    catch(error){if(!stored)throw error;restoreStatus='restore-rejected';console.log('Phien luu khong nap duoc; se dang nhap lai.');context=await browser.newContext(settings);}
    const page=await context.newPage();
    persistence=createLoginPersistence({root,context,page,target,restoreStatus});
    const session=await createRetrySession(context,page,new URL(target).origin);
    cpuBoost=await createCpuBoost({browser,enabled:testOptions.cpuBoostEnabled??true});session.cpuBoost=cpuBoost;
    session.persistence=persistence;
    page.on('close',()=>{stopped=true;});browser.on('disconnected',()=>{stopped=true;});
    void rl.question('Nhan Enter bat ky luc nao de DUNG TOAN BO LICH: ').then(()=>{stopped=true;}).catch(()=>{stopped=true;});
    console.log(stored?'Da thu nap phien luu. Neu trang chua dang nhap, tu dang nhap/xac minh trong 120 giay.':'Tu dang nhap va xac minh CAPTCHA/OTP; cho toi da 120 giay sau buoc mo trang.');
    try{await page.goto(target,{waitUntil:'domcontentloaded',timeout:60000});}catch{if(stopped)return;console.log('Trang tai cham; dang cho dang nhap.');}
    await waitForLogin(page,{timeoutMs:testOptions.loginTimeoutMs??LOGIN_TIMEOUT_MS,cancelled:()=>stopped});
    const schedule=determineRunTime(answer),firstWindow=testOptions.window??{startAt:schedule.startAt,endAt:schedule.endAt};
    persistence.setWindow(firstWindow);
    const savedNow=await persistence.checkpoint('login');
    if(savedNow.state==='saved')console.log('Da luu link-login va cookie-tai-khoan trong thu muc chuong trinh.');
    else if(savedNow.state==='deferred-near-round')console.log('Dang sat gio chay; se luu phien sau khi xong luot nay.');
    else console.log('Chua luu duoc phien; chuong trinh van tiep tuc. Kiem tra quyen ghi thu muc.');
    saveTimer=setInterval(()=>{void persistence.checkpoint('periodic');},300000);
    console.log('Da dang nhap. Lich se TU TIEP TUC sau moi phien.');
    scheduleResult=await runRetrySchedule(session,{firstWindow,
      outputDir:testOptions.outputDir??new URL('./reports/',import.meta.url),observeOnly,cancelled:()=>stopped,...testOptions.scheduleOptions});
    return scheduleResult;
  }catch(error){
    const messages={PUBLIC_HTTPS_URL_REQUIRED:'Can link HTTPS, khong kem mat khau trong link.',INVALID_HOUR:'Gio khong hop le.',LOGIN_TIMEOUT:'Het 120 giay chua dang nhap. Da dung va dong trinh duyet.'};
    if(stopped||['STOPPED','PAGE_CLOSED'].includes(error.message))console.log('Da dung chuong trinh.');
    else{console.error(messages[error.message]??'Khong chay duoc. Kiem tra Node.js 22+ va Edge/Chrome.');process.exitCode=1;}
  }finally{
    stopped=true;clearInterval(saveTimer);rl.close();
    if(cpuBoost)await cpuBoost.stop();
    if(scheduleResult?.lastReportFile)await writeFile(scheduleResult.lastReportFile,JSON.stringify(scheduleResult.lastReport,null,2)).catch(()=>{});
    if(persistence){const savedExit=await persistence.checkpoint('exit',{force:true});
      console.log(savedExit.state==='saved'?'Da cap nhat phien truoc khi dung.':'Chua luu duoc phien cuoi; dung ban luu gan nhat neu da co.');await persistence.finish();}
    if(browser)await browser.close().catch(()=>{});
  }
}
if(process.argv[1]===fileURLToPath(import.meta.url))await runPlan1();
