@echo off
setlocal
set "PA1_CHAT_LIGHT=0"
call "%~dp0start-pa1retry500.cmd"
endlocal
