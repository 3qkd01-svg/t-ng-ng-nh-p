import {spawn as spawnProcess} from 'node:child_process';
import {mkdtemp,writeFile,rename,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';

// A separate Windows watcher restores changed priorities on expiry, Stop or
// owner exit. It never changes CPU affinity, power plans or hardware clocks.
export async function createCpuBoost({browser,enabled=true,platform=process.platform,
  spawn=spawnProcess,readyTimeoutMs=8000,stopTimeoutMs=5000,pidTimeoutMs=3000,log=console.log}={}) {
  const reports=new Map();let state=!enabled?'disabled':platform!=='win32'?'unsupported-platform':'starting';
  let child,folder,control,sequence=0,closed=false,buffer='',resolveReady,resolveExit;
  const ready=new Promise(r=>{resolveReady=r;}),exited=new Promise(r=>{resolveExit=r;});
  const reportFor=windowStartAt=>{
    if(!reports.has(windowStartAt))reports.set(windowStartAt,{enabled:enabled&&platform==='win32',
      state,priority:'AboveNormal',startAt:new Date(windowStartAt-30000).toISOString(),
      endAt:new Date(windowStartAt+60000).toISOString(),affinityChanged:false,events:[]});
    return reports.get(windowStartAt);
  };
  async function command(action,windowStartAt=0){
    const temporary=control+'.next';
    await writeFile(temporary,JSON.stringify({action,windowStartAt,sequence:++sequence}),{mode:0o600});
    for(let attempt=0;;attempt++){
      try{await rename(temporary,control);break;}
      catch(error){if(attempt>=3)throw error;await new Promise(r=>setTimeout(r,20));}
    }
  }
  async function bounded(promise,ms){let timer;try{return await Promise.race([promise,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('CPU_TIMEOUT')),ms);})]);}finally{clearTimeout(timer);}}
  const api={reportFor,async schedule(windowStartAt){
    const report=reportFor(windowStartAt);
    if(state!=='ready'){report.state=state;return report;}
    report.state='scheduled';
    try{await command('schedule',windowStartAt);}catch{report.state='control-unavailable';}
    return report;
  },async stop(){
    if(!child||closed)return;
    try{await command('shutdown');}catch{}
    let timer;try{
      const done=await Promise.race([exited,new Promise(r=>{timer=setTimeout(()=>r(false),stopTimeoutMs);})]);
      if(!done){for(const r of reports.values())if(['active','scheduled'].includes(r.state))r.state='restore-pending';
        child.stdout?.destroy();child.stderr?.destroy();child.unref?.();}
    }finally{clearTimeout(timer);}
  }};
  if(state!=='starting')return api;
  try{
    const cdp=await bounded(browser.newBrowserCDPSession(),pidTimeoutMs);let info;
    try{info=await bounded(cdp.send('SystemInfo.getProcessInfo'),pidTimeoutMs);}finally{await bounded(cdp.detach().catch(()=>{}),1000).catch(()=>{});}
    const root=Number(info.processInfo?.find(p=>p.type==='browser')?.id);
    if(!Number.isSafeInteger(root)||root<=0)throw Error('PID_UNAVAILABLE');
    folder=await mkdtemp(join(tmpdir(),'pa1-cpu-'));control=join(folder,'control.json');
    await command('idle');
    child=spawn('powershell.exe',['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',
      fileURLToPath(new URL('./cpu-priority.ps1',import.meta.url)),'-BrowserProcessId',String(root),
      '-OwnerProcessId',String(process.pid),'-ControlPath',control],{windowsHide:true,stdio:['ignore','pipe','pipe']});
    const ended=()=>{if(closed)return;closed=true;state='unavailable';resolveReady(false);resolveExit(true);
      for(const r of reports.values())if(['active','scheduled'].includes(r.state))r.state='helper-exited';
      void rm(folder,{recursive:true,force:true}).catch(()=>{});};
    child.on('error',ended);child.on('close',ended);
    child.stderr?.on('data',()=>{});
    child.stdout.on('data',data=>{
      buffer+=data.toString('utf8');if(buffer.length>32768){buffer='';return;}
      let split;
      while((split=buffer.indexOf('\n'))>=0){
        const line=buffer.slice(0,split);buffer=buffer.slice(split+1);
        let event;try{event=JSON.parse(line);}catch{continue;}
        if(event.state==='ready'){state='ready';resolveReady(true);continue;}
        if(!['scheduled','active','restored','restore-incomplete','skipped','warning'].includes(event.state))continue;
        const report=reports.get(Number(event.windowStartAt));if(!report)continue;
        report.state=event.state;
        for(const k of ['appliedCount','restoredCount','goneCount','failedCount','externallyChangedCount','cpuCount'])
          if(Number.isSafeInteger(event[k])&&event[k]>=0)report[k]=event[k];
        const at=typeof event.at==='string'&&Number.isFinite(Date.parse(event.at))?event.at:new Date().toISOString();
        report.events.push({at,state:event.state});if(report.events.length>16)report.events.shift();
        if(event.state==='active')report.appliedAt??=at;
        if(event.state==='restored'||event.state==='restore-incomplete')report.restoredAt=at;
        if(['active','restored','restore-incomplete'].includes(event.state))log('CPU: '+event.state+'; AboveNormal; '+(report.appliedCount??0)+' tien trinh PA1.');
      }
    });
    let timer;try{
      const ok=await Promise.race([ready,new Promise(r=>{timer=setTimeout(()=>r(false),readyTimeoutMs);})]);
      if(!ok){state='unavailable';await api.stop();}
    }finally{clearTimeout(timer);}
  }catch{state='unavailable';resolveReady(false);if(folder&&!child)await rm(folder,{recursive:true,force:true}).catch(()=>{});}
  if(state!=='ready')log('CPU: khong ap dung duoc; chuong trinh van chay va ghi trang thai trong bao cao.');
  return api;
}
