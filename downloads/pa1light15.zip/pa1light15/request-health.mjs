// Local observations only. Never export request bodies, headers, IDs or cookies.
export const OPEN_TIMEOUT_MS = 60000;
export function classifyNotice(text) {
  const s=String(text??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  if(/lap lai qua thuong xuyen|qua nhieu (thao tac|yeu cau)|too (many|frequent)|rate.?limit/.test(s))return 'rate-limit';
  if(/network error.*no\s*res/.test(s))return 'network-no-response';
  if(/nhan li xi that bai/.test(s))return 'claim-failed';
  if(/timeout|timed out/.test(s))return 'timeout-notice';
  return null;
}
export function parseRetryAfter(value, now=Date.now()) {
  if(typeof value!=='string'||value.length>128)return null;
  const text=value.trim();
  if(/^\d+(?:\.\d+)?$/.test(text)) {
    const until=now+Number(text)*1000;
    return Number.isFinite(until)&&until<=8640000000000000?Math.ceil(until):null;
  }
  const until=Date.parse(text);return Number.isFinite(until)?Math.max(now,until):null;
}
export function readBusinessResult(buffer) {
  if(!buffer||buffer.length>524288)return {bodyState:'too-large'};
  try {
    const body=JSON.parse(buffer.toString('utf8'));
    const code=body?.code;
    let message=[body?.msg,body?.message,body?.error_message,body?.errorMessage].find(v=>typeof v==='string')??null;
    const messagePresent=message!==null;
    if(message) {
      message=message.replace(/<[^>]*>/g,' ').replace(/[\r\n\t]+/g,' ').trim().slice(0,240);
      if(/cookie|token|password|signature|authorization|bearer|PRIVATE_|https?:\/\/|[\w.+-]+@[\w.-]+|[A-Za-z0-9+/_=-]{24,}/i.test(message))message=null;
      else message=message.replace(/\b\d{8,}\b/g,'[redacted]');
    }
    return {bodyState:'parsed',applicationCode:Number.isInteger(code)&&Math.abs(code)<10000?code:null,
      applicationMessage:message,messagePresent,noticeCategory:classifyNotice(message)};
  }catch{return {bodyState:'not-json'};}
}
export function installRequestHealth({bindingName='__pa1HealthNotify',minimumMs=60000}={}) {
  if(window.__pa1RequestHealth)return;
  const state={blockedUntil:0,records:[],notices:[]};let sequence=0,queued=false,lastNotice='';
  const notify=event=>{try{Promise.resolve(window[bindingName]?.(event)).catch(()=>{});}catch{}};
  const category=text=>{
    const s=String(text??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
    if(/lap lai qua thuong xuyen|qua nhieu (thao tac|yeu cau)|too (many|frequent)|rate.?limit/.test(s))return 'rate-limit';
    if(/network error.*no\s*res/.test(s))return 'network-no-response';
    if(/nhan li xi that bai/.test(s))return 'claim-failed';
    return null;
  };
  function inspectNotices(){
    queued=false;let found='';
    for(const el of document.querySelectorAll('.van-toast,.van-notify,.el-message,.ant-message-notice-content')){
      if(!el.getClientRects().length||getComputedStyle(el).visibility==='hidden')continue;
      const kind=category((el.textContent||'').slice(0,512));if(!kind)continue;
      found=kind;if(kind===lastNotice)continue;
      const event={kind:'notice',category:kind,at:new Date().toISOString()};
      if(kind==='rate-limit')state.blockedUntil=Math.max(state.blockedUntil,Date.now()+60000);
      state.notices.push(event);if(state.notices.length>32)state.notices.shift();notify(event);
    }
    lastNotice=found;
  }
  function observe(){
    if(!document.documentElement)return;
    const observer=new MutationObserver(records=>{
      if(queued)return;
      const relevant=records.some(r=>{
        const el=r.target.nodeType===1?r.target:r.target.parentElement;
        if(el?.closest?.('.van-toast,.van-notify,.el-message,.ant-message-notice-content'))return true;
        return [...r.addedNodes].some(n=>n.nodeType===1&&(n.matches?.('.van-toast,.van-notify,.el-message,.ant-message-notice-content')||n.querySelector?.('.van-toast,.van-notify,.el-message,.ant-message-notice-content')));
      });
      if(relevant){queued=true;queueMicrotask(inspectNotices);}
    });
    observer.observe(document.documentElement,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['class','style']});
    inspectNotices();
  }
  window.__pa1RequestHealth=state;
  if(document.documentElement)observe();else document.addEventListener('DOMContentLoaded',observe,{once:true});
  const proto=XMLHttpRequest.prototype,open=proto.open,send=proto.send,selected=new WeakMap();
  proto.open=function(...args){
    const result=Reflect.apply(open,this,args);
    try{const u=new URL(args[1],location.href);selected.set(this,String(args[0]).toUpperCase()==='POST'&&u.origin===location.origin&&/\/chat\/grabred\/?$/i.test(u.pathname));}
    catch{selected.set(this,false);}return result;
  };
  proto.send=function(...args){
    if(selected.get(this)){
      const before=this.timeout;
      // An explicit unlimited timeout (0) stays unlimited; never shorten it.
      try{if(this.timeout>0&&this.timeout<minimumMs)this.timeout=minimumMs;}catch{}
      const started=performance.now(),item={number:++sequence,sentAt:new Date().toISOString(),originalTimeoutMs:before,timeoutMs:this.timeout,terminal:null};
      state.records.push(item);if(state.records.length>32)state.records.shift();
      const listener=event=>{
        if(item.terminal)return;
        item.terminal={type:event.type,at:new Date().toISOString(),elapsedMs:Math.round(performance.now()-started),httpStatus:this.status||null,actualTimeoutMs:this.timeout};
        notify({kind:'xhr-terminal',...item});
      };
      for(const kind of ['load','error','timeout','abort'])this.addEventListener(kind,listener,{once:true});
    }
    return Reflect.apply(send,this,args);
  };
}
