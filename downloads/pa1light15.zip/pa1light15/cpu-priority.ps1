param([int]$BrowserProcessId=0,[int]$OwnerProcessId=0,[string]$ControlPath='')
$ErrorActionPreference='Stop'

function Get-Identity($Process) {
    return [string]$Process.StartTime.ToUniversalTime().Ticks
}
function New-PriorityLease {
    return @{ Saved=@{}; Applied=0; Restored=0; Gone=0; Failed=0; External=0 }
}
function Add-PriorityProcess($Lease,[int]$ProcessId) {
    try {
        $process=Get-Process -Id $ProcessId -ErrorAction Stop
        $identity=Get-Identity $process
        $key=([string]$ProcessId)+':'+$identity
        if($Lease.Saved.ContainsKey($key)){return}
        $before=$process.PriorityClass
        # Leave existing High/RealTime priorities alone. Never set RealTime.
        if($before -in @('AboveNormal','High','RealTime')){return}
        $entry=@{ ProcessId=$ProcessId; Identity=$identity; Priority=$before }
        $process.PriorityClass=[Diagnostics.ProcessPriorityClass]::AboveNormal
        $Lease.Saved[$key]=$entry;$Lease.Applied++
    } catch { $Lease.Failed++ }
}
function Restore-PriorityLease($Lease) {
    foreach($entry in @($Lease.Saved.Values)) {
        try {
            $process=Get-Process -Id $entry.ProcessId -ErrorAction Stop
            if((Get-Identity $process) -ne $entry.Identity){$Lease.Gone++;continue}
            if($process.PriorityClass -eq [Diagnostics.ProcessPriorityClass]::AboveNormal){
                $process.PriorityClass=$entry.Priority;$Lease.Restored++
            } elseif($process.PriorityClass -ne $entry.Priority) { $Lease.External++ }
        } catch {
            try { Get-Process -Id $entry.ProcessId -ErrorAction Stop | Out-Null;$Lease.Failed++ }
            catch { $Lease.Gone++ }
        }
    }
    $Lease.Saved.Clear()
}
function Get-BrowserTree([int]$RootProcessId) {
    $rows=@(Get-CimInstance Win32_Process -Filter "Name='chrome.exe' OR Name='msedge.exe' OR Name='chromium.exe'" -ErrorAction Stop)
    $found=New-Object 'System.Collections.Generic.HashSet[int]'
    [void]$found.Add($RootProcessId)
    do {
        $added=$false
        foreach($row in $rows){
            if($found.Contains([int]$row.ParentProcessId) -and $found.Add([int]$row.ProcessId)){$added=$true}
        }
    } while($added)
    return @($found)
}
function Write-PriorityEvent([string]$State,[long]$WindowStartAt,$Lease) {
    $event=@{state=$State;windowStartAt=$WindowStartAt;at=[DateTime]::UtcNow.ToString('o');cpuCount=[Environment]::ProcessorCount}
    if($Lease){$event.appliedCount=$Lease.Applied;$event.restoredCount=$Lease.Restored;$event.goneCount=$Lease.Gone
        $event.failedCount=$Lease.Failed;$event.externallyChangedCount=$Lease.External}
    [Console]::Out.WriteLine(($event | ConvertTo-Json -Compress -Depth 4))
}
function Get-EpochMs { return [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() }
function Start-PriorityWatcher {
    if($BrowserProcessId -le 0 -or $OwnerProcessId -le 0 -or -not [IO.File]::Exists($ControlPath)){throw 'INVALID_ARGUMENTS'}
    $root=Get-Process -Id $BrowserProcessId -ErrorAction Stop
    if($root.ProcessName -notin @('chrome','msedge','chromium')){throw 'INVALID_BROWSER'}
    $rootIdentity=Get-Identity $root
    $ownerIdentity=Get-Identity (Get-Process -Id $OwnerProcessId -ErrorAction Stop)
    try{[Diagnostics.Process]::GetCurrentProcess().PriorityClass=[Diagnostics.ProcessPriorityClass]::BelowNormal}catch{}
    $lease=New-PriorityLease;$windowStartAt=0L;$lastSequence=-1L;$pending=$false;$active=$false
    $deadlineMono=0.0;$lastScan=-10000.0;$clock=[Diagnostics.Stopwatch]::StartNew()
    try {
        Write-PriorityEvent 'ready' 0 $null
        while($true){
            try {
                if((Get-Identity (Get-Process -Id $OwnerProcessId -ErrorAction Stop)) -ne $ownerIdentity){break}
                if((Get-Identity (Get-Process -Id $BrowserProcessId -ErrorAction Stop)) -ne $rootIdentity){break}
            } catch {break}
            $control=$null
            try{if((Get-Item -LiteralPath $ControlPath).Length -le 8192){$control=[IO.File]::ReadAllText($ControlPath) | ConvertFrom-Json}}catch{}
            if($control -and [long]$control.sequence -gt $lastSequence){
                $lastSequence=[long]$control.sequence
                if($control.action -eq 'shutdown'){break}
                if($control.action -eq 'schedule' -and [long]$control.windowStartAt -gt 0){
                    if($active){Restore-PriorityLease $lease;Write-PriorityEvent 'restored' $windowStartAt $lease}
                    $lease=New-PriorityLease;$windowStartAt=[long]$control.windowStartAt;$active=$false;$pending=$true
                    Write-PriorityEvent 'scheduled' $windowStartAt $lease
                }
            }
            $now=Get-EpochMs
            if($pending -and -not $active -and $now -ge ($windowStartAt-30000)){
                if($now -ge ($windowStartAt+60000)){$pending=$false;Write-PriorityEvent 'skipped' $windowStartAt $lease}
                else{$active=$true;$deadlineMono=$clock.Elapsed.TotalMilliseconds+[Math]::Min(90000,($windowStartAt+60000-$now));$lastScan=-10000}
            }
            if($active -and ($now -ge ($windowStartAt+60000) -or $clock.Elapsed.TotalMilliseconds -ge $deadlineMono)){
                Restore-PriorityLease $lease;$active=$false;$pending=$false
                $result=if($lease.Failed -gt 0){'restore-incomplete'}else{'restored'}
                Write-PriorityEvent $result $windowStartAt $lease
            }
            if($active -and $clock.Elapsed.TotalMilliseconds-$lastScan -ge 1000){
                $lastScan=$clock.Elapsed.TotalMilliseconds;$before=$lease.Applied
                # The PA1 controller needs scheduling time too; no other Node process is touched.
                Add-PriorityProcess $lease $OwnerProcessId
                try{foreach($processIdValue in (Get-BrowserTree $BrowserProcessId)){Add-PriorityProcess $lease $processIdValue}}
                catch{$lease.Failed++}
                if($lease.Applied -ne $before -or $before -eq 0){Write-PriorityEvent 'active' $windowStartAt $lease}
            }
            $wait=if($active -or ($pending -and $now -ge ($windowStartAt-35000))){250}else{1000}
            Start-Sleep -Milliseconds $wait
        }
    } finally {
        if($active){Restore-PriorityLease $lease
            $result=if($lease.Failed -gt 0){'restore-incomplete'}else{'restored'}
            Write-PriorityEvent $result $windowStartAt $lease}
    }
}
if($MyInvocation.InvocationName -ne '.') {
    try{Start-PriorityWatcher}catch{Write-PriorityEvent 'warning' 0 $null;exit 1}
}
