// Selective local Vuex display optimization. No WebSocket, auth or HTTP hooks.
export function installChatLight({enabled=true,receiptBatchMs=150}={}) {
  if(window.__pa1ChatLight)return;
  const ordinary=new Set(['string','img','share_order','chat_game_invite','chat_dragon','chat_mini_dragon']);
  const stats={enabled:!!enabled,state:enabled?'waiting-store':'disabled',profile:'vuex-chat-display-v1',
    suppressedLive:0,suppressedByType:Object.fromEntries([...ordinary].map(t=>[t,0])),
    historyRowsSeen:0,historyRowsRemoved:0,historyAnchorsKept:0,historyBatches:0,
    envelopesPassed:0,unknownPassed:0,receiptsQueued:0,receiptsApplied:0,receiptBatches:0,
    maxQueuedReceipts:0,paginationPrevented:0};
  let stopped=!enabled,store=null,room=null,storeHooks=[],roomHooks=[],timer=null,receiptTimer=null;
  let receipts=[],discoverUntil=Date.now()+120000,nextRoomSearch=0,flushing=false;
  const inChat=()=>/^#\/chatRoom(?:$|\?)/.test(location.hash);
  const suppress=item=>{
    if(!item||!ordinary.has(item.type))return false;
    const id=item.data?.red_id;
    return id==null||id===''||id===0||id==='0'||id===false;
  };
  function canonical(fn){
    const text=Function.prototype.toString.call(fn).replace(/\s+/g,'');
    const args=/^\(([\w$]+),([\w$]+)\)=>/.exec(text);if(!args||text.includes('__PA1_'))return '';
    const escape=s=>s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
    let value=text;
    for(const [name,label]of [[args[1],'__PA1_STATE__'],[args[2],'__PA1_PAYLOAD__']]){
      value=value.replace(new RegExp('(^|[^\\w$])'+escape(name)+'(?=$|[^\\w$])','g'),(_all,before)=>before+label);
    }
    return value.replaceAll('__PA1_STATE__','S').replaceAll('__PA1_PAYLOAD__','P');
  }
  const insertProfile='(S,P)=>{500<S.chatLog.length&&S.chatLog.splice(0,400),S.chatLog=S.chatLog.concat(newArray(P)),"chat_red_record"==P.type?S.scrollDown+=2:S.scrollDown+=1}';
  const initProfile='(S,P)=>{S.chatLog=P,setTimeout(()=>{S.scrollDown+=1},100)}';
  function matchesStore(value){
    try{
      const raw=value?._modulesNamespaceMap?.['chat/']?._rawModule;
      return Array.isArray(value?.state?.chat?.chatLog)&&typeof value._withCommit==='function'&&
        canonical(raw?.mutations?.INSERT_CHAT_LOG)===insertProfile&&canonical(raw?.mutations?.INIT_CHAT_LOG)===initProfile&&
        ['chat/INSERT_CHAT_LOG','chat/INIT_CHAT_LOG','chat/CLEAN_CHAT_LOG','chat/LOAD_MORE_CHAT_LOG','chat/INSERT_CHAT_LOG_BY_AT_MSG','chat/ADD_RED_NOTIFY_LIST','chat/DEL_RED_NOTIFY_LIST','chat/WS_IS_RED_PACK'].every(k=>Array.isArray(value._mutations?.[k])&&value._mutations[k].length===1);
    }catch{return false;}
  }
  function intact(){return storeHooks.every(h=>store._mutations?.[h.key]===h.list&&h.list[0]===h.wrapper);}
  function restoreRoom(){
    for(const h of roomHooks)if(h.target[h.name]===h.wrapper)h.target[h.name]=h.original;
    roomHooks=[];room=null;
  }
  function restoreStore(){for(const h of storeHooks)if(store._mutations?.[h.key]===h.list&&h.list[0]===h.wrapper)h.list[0]=h.original;storeHooks=[];}
  function stop(reason='stopped'){
    if(stopped)return;
    stopped=true;clearTimeout(timer);clearTimeout(receiptTimer);restoreStore();restoreRoom();
    // Deferred receipt rows are never discarded, including on a compatibility change.
    const pending=receipts;receipts=[];
    for(const item of pending)try{store.commit('chat/INSERT_CHAT_LOG',item);stats.receiptsApplied++;}catch{}
    window.removeEventListener('hashchange',onRoute);stats.state=reason;
  }
  function flushReceipts(){
    clearTimeout(receiptTimer);receiptTimer=null;if(!receipts.length||flushing)return;
    if(!store||!intact()||!Array.isArray(store.state.chat.chatLog)||!Number.isFinite(store.state.chat.scrollDown))return stop('store-changed');
    flushing=true;
    try{
      const pending=receipts;receipts=[];
      // This is the verified original INSERT_CHAT_LOG effect applied in one
      // state update: preserve ordering, the 500/400 cap and +2 per receipt.
      const list=store.state.chat.chatLog.slice();
      for(const item of pending){if(list.length>500)list.splice(0,400);list.push(item);}
      store._withCommit(()=>{store.state.chat.chatLog=list;store.state.chat.scrollDown+=pending.length*2;});
      stats.receiptsApplied+=pending.length;stats.receiptBatches++;
    }finally{flushing=false;}
  }
  function filterHistory(items){
    if(!Array.isArray(items))return items;
    const last=items.length-1,keep=[];
    for(let index=0;index<items.length;index++){
      const item=items[index];
      // Two native boundary rows preserve cursors and mention-related code.
      // isShowList hides these ordinary anchors; no fake message is inserted.
      if(!suppress(item)||index===0||index===last){keep.push(item);if(suppress(item))stats.historyAnchorsKept++;}
    }
    stats.historyBatches++;stats.historyRowsSeen+=items.length;stats.historyRowsRemoved+=items.length-keep.length;
    return keep;
  }
  function findRoom(){
    const root=document.querySelector('#app')?.__vue__,stack=[root],seen=new Set();
    while(stack.length&&seen.size<1000){const value=stack.pop();if(!value||seen.has(value))continue;seen.add(value);
      if(value.$store===store&&typeof value.getChatGrabred==='function'&&'redPackDetail'in value)return value;
      stack.push(...(value.$children||[]));}
    return null;
  }
  function attachRoom(value){
    const methods=value?.$options?.methods??{};
    if(!value?.$el?.isConnected||value._isDestroyed||typeof value.isShowList!=='function'||typeof value.refreshChatLog!=='function')return false;
    const open=String(methods.getChatGrabred??'');
    if(!open.includes('chat/chatGrabred')||!open.includes('showRedPackExpired')||!open.includes('showRedPackDetail')){stop('unsupported-room');return false;}
    room=value;
    const originalShow=value.isShowList,show=function(item,...args){if(!stopped&&inChat()&&suppress(item))return false;return Reflect.apply(originalShow,this,[item,...args]);};
    value.isShowList=show;roomHooks.push({target:value,name:'isShowList',original:originalShow,wrapper:show});
    const originalRefresh=value.refreshChatLog;
    const refresh=function(...args){
      if(!stopped&&inChat()){
        stats.paginationPrevented++;
        const scroll=this.$refs?.chatLogScroll?.scroll;scroll?.finishPullDown?.();return;
      }
      return Reflect.apply(originalRefresh,this,args);
    };
    value.refreshChatLog=refresh;roomHooks.push({target:value,name:'refreshChatLog',original:originalRefresh,wrapper:refresh});
    stats.state='active';
    // If initial history beat discovery, prune it once without another HTTP call.
    const history=store.state.chat.chatLog;
    if(history.length>2&&history.some((v,index)=>index>0&&index<history.length-1&&suppress(v)))store.commit('chat/INIT_CHAT_LOG',history);
    return true;
  }
  function active(){
    if(stopped||!store||!inChat())return false;
    if(!intact()){stop('store-changed');return false;}
    if(room&&!room._isDestroyed&&room.$el?.isConnected)return true;
    if(room)restoreRoom();
    if(Date.now()<nextRoomSearch)return false;nextRoomSearch=Date.now()+100;
    return attachRoom(findRoom());
  }
  function attachStore(value){
    store=value;
    for(const key of ['chat/INSERT_CHAT_LOG','chat/INIT_CHAT_LOG','chat/CLEAN_CHAT_LOG','chat/LOAD_MORE_CHAT_LOG','chat/INSERT_CHAT_LOG_BY_AT_MSG']){
      const list=store._mutations[key],original=list[0];
      const wrapper=function(payload,...args){
        if(!['chat/INSERT_CHAT_LOG','chat/INIT_CHAT_LOG'].includes(key)){
          // Keep native clear/history/mention ordering. In particular, queued
          // rows must never reappear after logout clears the chat log.
          flushReceipts();return Reflect.apply(original,this,[payload,...args]);
        }
        if(!active())return Reflect.apply(original,this,[payload,...args]);
        if(key==='chat/INSERT_CHAT_LOG'){
          if(suppress(payload)){stats.suppressedLive++;stats.suppressedByType[payload.type]++;return;}
          if(payload?.type==='chat_red_record'){
            receipts.push(payload);stats.receiptsQueued++;stats.maxQueuedReceipts=Math.max(stats.maxQueuedReceipts,receipts.length);
            if(receipts.length>=128)flushReceipts();
            else if(receiptTimer===null)receiptTimer=setTimeout(flushReceipts,Math.min(250,Math.max(10,receiptBatchMs)));
            return;
          }
          // Envelope cards and unknown/control-related entries never wait for a timer.
          flushReceipts();
          if(payload?.type==='chat_red')stats.envelopesPassed++;else stats.unknownPassed++;
          return Reflect.apply(original,this,[payload,...args]);
        }
        flushReceipts();return Reflect.apply(original,this,[filterHistory(payload),...args]);
      };
      list[0]=wrapper;storeHooks.push({key,list,original,wrapper});
    }
    stats.state='ready';
  }
  function discover(){
    clearTimeout(timer);timer=null;if(stopped)return;
    if(!store){const value=document.querySelector('#app')?.__vue__?.$store;
      if(value?._modulesNamespaceMap?.['chat/']){
        if(!matchesStore(value)){stats.state='unsupported-store';return;}
        attachStore(value);
      }
    }
    if(store&&inChat())active();
    if(!stopped&&Date.now()<discoverUntil&&(!store||(inChat()&&!room)))timer=setTimeout(discover,store?100:250);
  }
  function onRoute(){
    if(stopped)return;
    if(!inChat()){flushReceipts();restoreRoom();if(!stopped)stats.state=store?'ready':'waiting-store';return;}
    nextRoomSearch=0;discoverUntil=Date.now()+20000;discover();
  }
  window.__pa1ChatLight={version:1,stop,snapshot(){
    if(!stopped&&store&&!intact())stop('store-changed');
    return {...stats,suppressedByType:{...stats.suppressedByType},pendingReceipts:receipts.length,
      currentRows:store?.state?.chat?.chatLog?.length??null,capturedAt:new Date().toISOString(),scope:'current-document'};
  }};
  if(enabled){window.addEventListener('hashchange',onRoute);discover();}
}

// Whitelist diagnostic fields; never export message objects or user identifiers.
export function sanitizeChatLightSnapshot(value,enabled=true){
  if(!value||typeof value!=='object')return {enabled,state:'snapshot-unavailable'};
  const states=['disabled','waiting-store','unsupported-store','unsupported-room','ready','active','stopped','store-changed'];
  const out={enabled:value.enabled===true,state:states.includes(value.state)?value.state:'snapshot-unavailable',scope:'current-document'};
  for(const name of ['suppressedLive','historyRowsSeen','historyRowsRemoved','historyAnchorsKept','historyBatches','envelopesPassed','unknownPassed','receiptsQueued','receiptsApplied','receiptBatches','maxQueuedReceipts','paginationPrevented','pendingReceipts','currentRows'])
    if(Number.isSafeInteger(value[name])&&value[name]>=0)out[name]=value[name];
  out.suppressedByType={};for(const name of ['string','img','share_order','chat_game_invite','chat_dragon','chat_mini_dragon'])
    if(Number.isSafeInteger(value.suppressedByType?.[name])&&value.suppressedByType[name]>=0)out.suppressedByType[name]=value.suppressedByType[name];
  if(typeof value.capturedAt==='string'&&value.capturedAt.length<=40&&Number.isFinite(Date.parse(value.capturedAt)))out.capturedAt=new Date(value.capturedAt).toISOString();
  return out;
}
