// Recover through normal site navigation; never request tokens directly.
export function createChatRecovery({ healthy, recover, ready, canRecover, log, now = Date.now,
  canObserve = canRecover, graceMs = 12000, cooldownMs = 15000, maxAttempts = 3, initiallyReady = true }) {
  let lostAt = null, lastAttempt = -Infinity, attempts = 0, busy = false, closed = false;
  let wasHealthy = initiallyReady, confirmedBefore = initiallyReady, state = initiallyReady ? 'ready' : 'waiting-initial';
  return {
    async tick() {
      if (closed || !canObserve() || busy) return;
      busy = true;
      try {
        if (healthy()) {
          const accepted = wasHealthy || await ready(true) !== false;
          if (closed || !canObserve()) return;
          if (accepted && healthy()) {
            if (!wasHealthy) log(confirmedBefore ? 'connection-restored' : 'connection-confirmed');
            lostAt = null; wasHealthy = true; confirmedBefore = true; state = 'ready';
            return;
          }
        }
        if (lostAt === null) {
          lostAt = now(); wasHealthy = false;
          await ready(false);
          if (closed || !canObserve()) return;
          log(confirmedBefore ? 'connection-lost' : 'initial-connection-waiting');
        }
        state = attempts >= maxAttempts ? 'budget-exhausted' : 'waiting-recovery';
        if (closed || !canObserve() || !canRecover() || attempts >= maxAttempts || now() - lostAt < graceMs || now() - lastAttempt < cooldownMs) return;
        lastAttempt = now(); attempts++;
        state = 'recovering'; log('recovery-attempt-' + attempts);
        try { await recover(); } catch { if (!closed && canObserve()) log('recovery-navigation-failed'); }
        if (closed || !canObserve()) return;
        state = attempts >= maxAttempts ? 'budget-exhausted' : 'waiting-recovery';
        if (attempts === maxAttempts) log('recovery-budget-used');
      } finally { busy = false; }
    },
    stop: () => { closed = true; },
    snapshot: () => ({ attempts, maxAttempts, graceMs, cooldownMs, state, confirmedBefore })
  };
}
